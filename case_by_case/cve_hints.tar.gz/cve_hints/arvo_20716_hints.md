# CVE/OSV Hints for arvo_20716

## Project: opensc
## Binary: /out/fuzz_pkcs15_reader
## Summary: dnie module length check

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=20716

## Details
arvo ID = oss-fuzz issue #20716. OpenSC dnie module doesn't check uncompressed data length.
OpenSC has many CVEs (CVE-2026-40510 stack overflow, CVE-2023-2997, etc.). Check x41-2018-002 advisory for OpenSC vulns.
