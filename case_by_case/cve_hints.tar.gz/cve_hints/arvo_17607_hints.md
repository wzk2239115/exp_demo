# CVE/OSV Hints for arvo_17607

## Project: poppler
## Binary: /out/pdf_fuzzer
## Summary: Use-of-uninitialized-value in AnnotAppearanceBuilder::drawText

## OSV ID: OSV-2020-1264
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=17607

## Details
arvo ID = oss-fuzz issue #17607. Uninitialized memory in Annot::layoutText.
Input: crafted PDF with broken annotation. Poppler has many CVEs — check CVE-2020-27778 (uninitialized pointer in poppler).
