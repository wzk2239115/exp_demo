# CVE/OSV Hints for arvo_47601

## Project: ghostscript
## Binary: /out/gstoraster_fuzzer
## Summary: stack object used without reference

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=47601

## Details
arvo ID = oss-fuzz issue #47601. Ghostscript object used from stack without taking reference.
Repair can flush stack → use-after-free. Input: crafted PostScript/PDF.
