# CVE/OSV Hints for arvo_44983

## Project: ghostscript
## Binary: /out/gstoraster_fuzzer
## Summary: /Length value in Encrypt dictionary

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=44983

## Details
arvo ID = oss-fuzz issue #44983. Ghostscript PDF encryption /Length handling.
Input: crafted PDF with invalid encryption dictionary.
