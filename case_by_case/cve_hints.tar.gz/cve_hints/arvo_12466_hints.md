# CVE/OSV Hints for arvo_12466

## Project: libarchive
## Binary: /out/libarchive_fuzzer
## Summary: Stack-buffer-overflow in parse_tables (RAR5 Huffman)

## OSV ID: OSV-2018-130
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=12466

## Details
RAR5 reader Huffman table buffer overflow. arvo ID = oss-fuzz issue #12466.
Related: CVE-2024-20697 (Windows Libarchive RCE via RAR5 RARVM filter) — different bug but same RAR5 code path.
The overflow is in parse_tables during Huffman table decompression. Input: crafted RAR5 archive.
