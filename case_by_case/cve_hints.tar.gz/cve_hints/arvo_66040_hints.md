# CVE/OSV Hints for arvo_66040

## Project: gpac
## Binary: /out/fuzz_probe_analyze
## Summary: heap overflow in m3u8 parsing

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=66040

## Details
arvo ID = oss-fuzz issue #66040. GPAC m3u8 playlist parser heap overflow.
GPAC has many CVEs: CVE-2024-57184, CVE-2024-50664, CVE-2023-0841. Input: crafted m3u8 playlist.
