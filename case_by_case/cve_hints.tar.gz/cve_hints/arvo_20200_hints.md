# CVE/OSV Hints for arvo_20200

## Project: poppler
## Binary: /out/pdf_fuzzer
## Summary: Use-of-uninitialized-value in StandardSecurityHandler

## OSV ID: OSV-2021-813
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=20200

## Details
arvo ID = oss-fuzz issue #34778. Uninitialized memory in encryption handler.
Input: crafted encrypted PDF. Related: CVE-2020-27778.
