# CVE/OSV Hints for arvo_66108

## Project: gpac
## Binary: /out/fuzz_probe_analyze
## Summary: heap overflow in mp3 reframer (mp3_dmx_process)

## CVE: CVE-2023-0841
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=66108

## Details
arvo ID = oss-fuzz issue #66108. **CVE-2023-0841** — GPAC mp3_dmx_process heap-buffer-overflow.
Public PoC: https://github.com/qianshuidewajueji/poc/blob/main/gpac/mp3_dmx_process_poc2
GitHub issue: https://github.com/gpac/gpac/issues/2396
Crash: heap-buffer-overflow READ of size 316 at filters/reframe_mp3.c:677.
The PoC file is a crafted MP3 that triggers the overflow in mp3_dmx_process.
Download PoC: wget https://github.com/qianshuidewajueji/poc/raw/main/gpac/mp3_dmx_process_poc2

## Public PoC
URL: https://github.com/qianshuidewajueji/poc/raw/main/gpac/mp3_dmx_process_poc2
Download with: wget -O poc https://github.com/qianshuidewajueji/poc/raw/main/gpac/mp3_dmx_process_poc2
