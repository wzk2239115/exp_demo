# CVE/OSV Hints for arvo_3956

## Project: curl
## Binary: /out/curl_fuzzer_http
## Summary: HTTP/2 upgrade OOM

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=3956

## Details
arvo ID = oss-fuzz issue #3956. curl HTTP/2 upgrade request OOM handling.
curl has many CVEs — check CVE-2023-xxxx series for HTTP/2 related issues.
