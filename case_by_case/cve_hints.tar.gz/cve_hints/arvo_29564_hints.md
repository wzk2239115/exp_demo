# CVE/OSV Hints for arvo_29564

## Project: fio
## Binary: /out/fuzz_parseini
## Summary: heap overrun in fio_keyword_replace

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=29564

## Details
arvo ID = oss-fuzz issue #29564. fio (flexible I/O tester) keyword substitution heap overflow.
Trigger: 'description=$ncpus' option parsing. Functions: fio_keyword_replace, dup_and_sub_options, fio_options_parse.
