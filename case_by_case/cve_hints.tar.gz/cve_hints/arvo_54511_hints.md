# CVE/OSV Hints for arvo_54511

## Project: ghostpdl
## Binary: /out/gs_device_pxlmono_fuzzer
## Summary: pdfi interpreter gsave level mismatch

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=54511

## Details
arvo ID = oss-fuzz issue #54511. GhostPDL pdfi interpreter doesn't clean up gsave levels after annotations.
Extra gsave levels persist → crashes. Input: crafted PDF with annotations/acroforms.
