# CVE/OSV Hints for arvo_51618

## Project: ghostpdl
## Binary: /out/gs_device_ps2write_fuzzer
## Summary: Ins_PUSHW missing bounds check

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=51618

## Details
arvo ID = oss-fuzz issue #51618. GhostPDL TrueType bytecode interpreter Ins_PUSHW bounds check missing.
Related: CVE-2022-31782 (freetype heap overflow in bytecode interpreter). Input: crafted font file.
