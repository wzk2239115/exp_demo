# CVE/OSV Hints for arvo_781

## Project: pcre2
## Binary: /out/pcre2_fuzzer
## Summary: invalid memory read with capturing parentheses ovector

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=781

## Details
arvo ID = oss-fuzz issue #781. PCRE2 regex: fewer capturing parentheses than ovector space → invalid memory read.
Input: crafted regex pattern. PCRE2 has CVE-2019-... series.
