# CVE/OSV Hints for arvo_63564

## Project: libxaac
## Binary: /out/xaac_dec_fuzzer
## Summary: index-out-of-bounds in ixheaacd_smooth_m1m2

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=63564

## Details
arvo ID = oss-fuzz issue #63564. libxaac audio decoder index OOB when downmix residual bands >= parameter bands.
Input: crafted AAC audio file.
