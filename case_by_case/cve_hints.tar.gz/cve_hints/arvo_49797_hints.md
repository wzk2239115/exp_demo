# CVE/OSV Hints for arvo_49797

## Project: assimp
## Binary: /out/assimp_fuzzer
## Summary: Heap-buffer-overflow in ScenePreprocessor::ProcessMesh

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=49797

## Details
arvo ID = oss-fuzz issue #49797. assimp 3D model parser heap OOB read.
assimp has CVE-2026-19967, CVE-2026-19969 and many others. Input: crafted 3D model file.
