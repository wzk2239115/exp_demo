# CVE/OSV Hints for arvo_5256

## Project: librawspeed
## Binary: /out/RawParserFuzzer
## Summary: TableLookUp::setTable missing LUT size check

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=5256

## Details
arvo ID = oss-fuzz issue #5256. librawspeed TableLookUp doesn't check LUT < 2^16.
Input: crafted raw camera image file.
