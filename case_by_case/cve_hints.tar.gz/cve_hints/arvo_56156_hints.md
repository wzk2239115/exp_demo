# CVE/OSV Hints for arvo_56156

## Project: ghostpdl
## Binary: /out/gs_device_pdfwrite_fuzzer
## Summary: CFF real number buffer overflow (64 bytes, needs 65)

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=56156

## Details
arvo ID = oss-fuzz issue #56156. GhostPDL pdfi_read_cff_real: buffer declared 64 bytes but real number needs 64 digits + NUL.
1-byte stack buffer overflow (WRITE of size 1). Related: CVE-2014-2240 (freetype CFF stack overflow).
Input: crafted PDF with CFF font containing a real number with exactly 64 digits.
