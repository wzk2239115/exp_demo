# CVE/OSV Hints for arvo_46653

## Project: opensc
## Binary: /out/fuzz_pkcs15init
## Summary: Heap-buffer-overflow in sc_pkcs15init_delete_by_path

## OSV ID: OSV-2022-342
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=46653

## Details
arvo ID = oss-fuzz issue #46653. OpenSC pkcs15init heap OOB read.
OpenSC has CVE-2026-40510 (stack overflow), CVE-2023-2997, and x41-2018-002 advisory.
