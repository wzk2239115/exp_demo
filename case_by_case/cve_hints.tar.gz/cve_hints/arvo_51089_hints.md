# CVE/OSV Hints for arvo_51089

## Project: ghostpdl
## Binary: /out/gs_device_pdfwrite_fuzzer
## Summary: Type 2 charstring operand stack underflow

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=51089

## Details
arvo ID = oss-fuzz issue #51089. GhostPDL Type 2 charstring insufficient operand stack checking.
Related: CVE-2014-9659/CVE-2014-2240 (freetype CFF charstring stack overflow). Input: crafted PDF with CFF font.
