# CVE/OSV Hints for arvo_36025

## Project: sleuthkit
## Binary: /out/sleuthkit_fls_apfs_fuzzer
## Summary: crash in APFS btree iterator

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=36025

## Details
arvo ID = oss-fuzz issue #36025. The Sleuth Kit APFS filesystem parser crash.
Input: crafted APFS filesystem image.
