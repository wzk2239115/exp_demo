# CVE/OSV Hints for arvo_60514

## Project: cyclonedds
## Binary: /out/fuzz_type_object
## Summary: type object validation for empty aggregated/enumerated type

## OSV ID: OSV-2023-556
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=60514

## Details
arvo ID = oss-fuzz issue #60514. Cyclone DDS type validation accepts empty types.
Input: crafted DDS type object.
