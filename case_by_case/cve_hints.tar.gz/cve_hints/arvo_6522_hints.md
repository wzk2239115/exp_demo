# CVE/OSV Hints for arvo_6522

## Project: mupdf
## Binary: /out/pdf_fuzzer
## Summary: image interpolation fixpoint overflow

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=6522

## Details
arvo ID = oss-fuzz issue #6522. MuPDF image painting with interpolation: 16.16 fixpoint limits width/height to 32767.
No size check → overflow → OOB accesses. Input: crafted PDF with large image.
