# CVE/OSV Hints for arvo_61718

## Project: libheif
## Binary: /out/file_fuzzer
## Summary: invalid mask region image references

## OSV ID: OSV-2023-330
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=61718

## Details
arvo ID = oss-fuzz issue #61718. libheif doesn't detect invalid mask region image references.
Related: OSV-2023-332 (RegionGeometry_Polygon). Input: crafted HEIF image.
