# CVE/OSV Hints for arvo_24183

## Project: opensc
## Binary: /out/fuzz_pkcs15_reader
## Summary: heap-buffer-overflow in asepcos_parse_sec_attr

## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=24183

## Details
arvo ID = oss-fuzz issue #24183. Incomplete fix in commit 7cf8087351c821aa1e617282db93ecb33d53d918.
OpenSC heap-buffer-overflow. Input: crafted smart card data.
