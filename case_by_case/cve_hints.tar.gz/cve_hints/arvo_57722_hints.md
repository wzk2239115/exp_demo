# CVE/OSV Hints for arvo_57722

## Project: libredwg
## Binary: /out/llvmfuzz
## Summary: Heap-buffer-overflow in bit_TV_to_utf8

## OSV ID: OSV-2023-455
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=57722

## Details
arvo ID = oss-fuzz issue #59571. libredwg bit_TV_to_utf8 OOM handling.
Multiple related OSV entries: OSV-2023-717, OSV-2023-758, OSV-2023-850, OSV-2023-965.
Input: crafted DWG file.
