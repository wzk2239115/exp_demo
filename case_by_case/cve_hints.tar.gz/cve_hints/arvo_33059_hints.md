# CVE/OSV Hints for arvo_33059

## Project: libredwg
## Binary: /out/llvmfuzz
## Summary: Segv in dwg_free_summaryinfo (uninitialized pointer)

## OSV ID: OSV-2021-620
## OSS-Fuzz Issue: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=33059

## Details
arvo ID = oss-fuzz issue #33059. dwg_read_dxf fails → partially initialized summaryinfo → crash on free.
Input: crafted DXF file. libredwg has CVE-2026B-90622 and others.
